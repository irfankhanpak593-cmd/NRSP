# NRSP Monthly Dashboard — Online APK Build

This project is prepared for a cloud/online Android builder.

## Fastest free route: GitHub Actions
1. Create a new GitHub repository.
2. Upload all files from this project (including `.github/workflows/build-apk.yml`).
3. Open **Actions → Build APK → Run workflow**.
4. When the workflow finishes, open the run and download the artifact:
   **NRSP-Monthly-Dashboard-APK**
5. Extract the artifact and install the `.apk` on Android.

The workflow builds a **debug APK**, so it does not require a signing key.

## Fields included
- Target for This Month
- Today Social Appraisal
- Total Appraisal
- RO Submit
- Disbursement
- Total Client
- Pending Recovery

## Important
The project is an Android app and can also be imported into Android Studio or another Gradle-compatible online builder.
