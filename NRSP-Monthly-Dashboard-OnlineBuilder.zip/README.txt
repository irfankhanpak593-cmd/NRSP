NRSP Monthly Dashboard Android app project.
Fields: Target for this month, Today Social Appraisal, Total Appraisal, RO Submit, Disbursement, Total Client, Pending Recovery.
Open in Android Studio and Build > Build APK(s).
