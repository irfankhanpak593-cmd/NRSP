package com.example.nrspdashboard;
import android.app.*;import android.os.*;import android.graphics.Typeface;import android.view.*;import android.widget.*;
public class MainActivity extends Activity{
 EditText target,today,total,ro,disbursement,clients,pending; TextView result;
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
 target=findViewById(R.id.target);today=findViewById(R.id.today);total=findViewById(R.id.total);ro=findViewById(R.id.ro);disbursement=findViewById(R.id.disbursement);clients=findViewById(R.id.clients);pending=findViewById(R.id.pending);result=findViewById(R.id.result);
 findViewById(R.id.save).setOnClickListener(v->show()); findViewById(R.id.clear).setOnClickListener(v->{target.setText("");today.setText("");total.setText("");ro.setText("");disbursement.setText("");clients.setText("");pending.setText("");result.setText("Report will appear here");}); }
 String v(EditText e){return e.getText().toString().trim().isEmpty()?"0":e.getText().toString().trim();}
 void show(){result.setText("TARGET FOR THIS MONTH     "+v(target)+"\n\nTODAY SOCIAL APPRAISAL     "+v(today)+"\n\nTOTAL APPRAISAL             "+v(total)+"\n\nRO SUBMIT                    "+v(ro)+"\n\nDISBURSEMENT                 "+v(disbursement)+"\n\nTOTAL CLIENT                 "+v(clients)+"\n\nPENDING RECOVERY             "+v(pending));}
}
